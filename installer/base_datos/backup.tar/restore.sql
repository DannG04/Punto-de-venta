--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.7
-- Dumped by pg_dump version 17.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE punto_de_venta;
--
-- Name: punto_de_venta; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE punto_de_venta WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE punto_de_venta OWNER TO postgres;

\connect punto_de_venta

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: curp_dominio; Type: DOMAIN; Schema: public; Owner: postgres
--

CREATE DOMAIN public.curp_dominio AS character varying(18)
	CONSTRAINT curp_dominio_check CHECK (((VALUE)::text ~ '^[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])[HM]{1}(AS|BC|BS|CC|CL|CM|CS|CH|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE)[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$'::text));


ALTER DOMAIN public.curp_dominio OWNER TO postgres;

--
-- Name: estadoValido; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."estadoValido" AS ENUM (
    'Vigente',
    'Entregado',
    'Cancelado',
    'Anulado'
);


ALTER TYPE public."estadoValido" OWNER TO postgres;

--
-- Name: estatusValido; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."estatusValido" AS ENUM (
    'Activo',
    'Inactivo'
);


ALTER TYPE public."estatusValido" OWNER TO postgres;

--
-- Name: id_producto_dominio; Type: DOMAIN; Schema: public; Owner: postgres
--

CREATE DOMAIN public.id_producto_dominio AS character varying(50)
	CONSTRAINT id_producto_dominio_check CHECK (((VALUE)::text ~ '^[A-Za-z0-9_-]{3,50}$'::text));


ALTER DOMAIN public.id_producto_dominio OWNER TO postgres;

--
-- Name: puestoValido; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."puestoValido" AS ENUM (
    'gerente',
    'vendedor'
);


ALTER TYPE public."puestoValido" OWNER TO postgres;

--
-- Name: tipoVenta; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."tipoVenta" AS ENUM (
    'Mayoreo',
    'Menudeo'
);


ALTER TYPE public."tipoVenta" OWNER TO postgres;

--
-- Name: act_apartado(character varying, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.act_apartado(ideap character varying, cantdd numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	cantt NUMERIC(10,2);
BEGIN
	SELECT cantidad_total INTO cantt FROM apartado WHERE id_apartado=ideap;
	IF cantdd >= cantt THEN
		RAISE EXCEPTION 'Ya que es un apartado, no es posible registrar una cantidad pagada mayor al total del apartado.
		Si se desea pagar completo el apartado, registrelo como una venta';
	ELSE
		cantt := cantt - cantdd;
		UPDATE apartado SET cantidad_dada=cantdd, cantidad_faltante=cantt WHERE id_apartado=ideap;
	END IF;
END;
$$;


ALTER FUNCTION public.act_apartado(ideap character varying, cantdd numeric) OWNER TO postgres;

--
-- Name: act_productos_inventario(boolean, public.id_producto_dominio, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.act_productos_inventario(incrementar boolean, ideprod public.id_producto_dominio, cant integer) RETURNS void
    LANGUAGE plpgsql
    AS $$ BEGIN IF incrementar THEN UPDATE producto SET cantidad = cantidad + cant WHERE id_producto = ideprod; ELSE UPDATE producto SET cantidad = cantidad - cant WHERE id_producto = ideprod; END IF; END; $$;


ALTER FUNCTION public.act_productos_inventario(incrementar boolean, ideprod public.id_producto_dominio, cant integer) OWNER TO postgres;

--
-- Name: actualizar_desc_temp(public.id_producto_dominio, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.actualizar_desc_temp(p_id_producto public.id_producto_dominio, p_descuento numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE venta_temp
    SET descuento_pct = p_descuento
    WHERE id_producto = p_id_producto;
END;
$$;


ALTER FUNCTION public.actualizar_desc_temp(p_id_producto public.id_producto_dominio, p_descuento numeric) OWNER TO postgres;

--
-- Name: anticipo_clientes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anticipo_clientes() RETURNS numeric
    LANGUAGE plpgsql
    AS $$
declare 
	anticipo decimal(20,2);
begin 
	SELECT SUM(cantidad_dada) INTO anticipo FROM apartado WHERE estado='Vigente';
	return anticipo;
end;
$$;


ALTER FUNCTION public.anticipo_clientes() OWNER TO postgres;

--
-- Name: anular_ap(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.anular_ap(ideapart character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	act DATE;
	ini DATE;
	fin DATE;
	cantd NUMERIC(10,2);
BEGIN
	SELECT fecha_inicio, fecha_limite INTO ini, fin FROM apartado WHERE id_apartado=ideapart;
	act := CURRENT_DATE;
	IF act NOT BETWEEN ini AND fin THEN
		SELECT cantidad_dada INTO cantd FROM apartado WHERE id_apartado=ideapart;
		UPDATE apartado SET estado='Anulado' WHERE id_apartado=ideapart;
		INSERT INTO otras_ganancias(descripcion, monto) VALUES('Anulación del apartado: ' || ideapart, cantd);
		PERFORM regresar_productos_inv(ideapart);
	END IF;
END;
$$;


ALTER FUNCTION public.anular_ap(ideapart character varying) OWNER TO postgres;

--
-- Name: ap_vigentes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ap_vigentes() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	ideap VARCHAR(15);
BEGIN
	FOR ideap IN SELECT id_apartado FROM apartado WHERE estado='Vigente'
		LOOP
			PERFORM anular_ap(ideap);
		END LOOP;
END;
$$;


ALTER FUNCTION public.ap_vigentes() OWNER TO postgres;

--
-- Name: balance_general(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.balance_general(inicio date, fin date) RETURNS TABLE(caja numeric, inventario numeric, clientes numeric)
    LANGUAGE plpgsql
    AS $$
declarE
begin
	RETURN QUERY
	SELECT 
		(SELECT total_caja(inicio,fin)) AS caja,
		(SELECT total_inventario()) AS inventario,
		(SELECT total_clientes()) AS clientes;
end;
$$;


ALTER FUNCTION public.balance_general(inicio date, fin date) OWNER TO postgres;

--
-- Name: cancelar_ap(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancelar_ap(ideap character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	est "estadoValido";
	mon NUMERIC(10,2);
BEGIN
	SELECT estado INTO est FROM apartado WHERE id_apartado=ideap;
	IF est='Cancelado' THEN
		RAISE EXCEPTION 'El apartado ya ha sido cancelado';
	ELSIF est='Entregado' THEN
		RAISE EXCEPTION 'El apartado ya ha sido entregado';
	ELSE
		UPDATE apartado SET estado='Cancelado' WHERE id_apartado=ideap;
		SELECT cancelar_ap_cliente(ideap) INTO mon;
		INSERT INTO otras_ganancias(descripcion, monto) VALUES('Cancelación del apartado: ' || ideap, mon);
		PERFORM regresar_productos_inv(ideap);
	END IF;
END;
$$;


ALTER FUNCTION public.cancelar_ap(ideap character varying) OWNER TO postgres;

--
-- Name: cancelar_ap_cliente(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancelar_ap_cliente(ideap character varying) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
	ini DATE;
	fin DATE;
	cant NUMERIC(10,2);
	cantt NUMERIC(10,2);
	dias INTEGER;
	diast INTEGER;
BEGIN
	SELECT fecha_inicio, fecha_limite, cantidad_dada INTO ini, fin, cantt
	FROM apartado WHERE id_apartado=ideap;
	dias := CURRENT_DATE - ini;
	diast := fin - ini;
	cant := (dias::NUMERIC / diast) * cantt;
	RETURN cant;
END;
$$;


ALTER FUNCTION public.cancelar_ap_cliente(ideap character varying) OWNER TO postgres;

--
-- Name: delete_producto(public.id_producto_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_producto(ideprod public.id_producto_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE cant INTEGER; BEGIN SELECT cantidad INTO cant FROM producto WHERE id_producto=ideprod; IF cant=0 THEN DELETE FROM producto WHERE id_producto=ideprod; ELSE RAISE EXCEPTION 'No es posible eliminar un producto con stock mayor a 0'; END IF; END; $$;


ALTER FUNCTION public.delete_producto(ideprod public.id_producto_dominio) OWNER TO postgres;

--
-- Name: elim_apartado(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_apartado(ideap character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	cant INTEGER;
BEGIN
	SELECT COUNT(id_apartado) INTO cant FROM apartado_detalle WHERE id_apartado=ideap;
	IF cant=0 THEN
		DELETE FROM apartado WHERE id_apartado=ideap;
	ELSE
		RAISE EXCEPTION 'No es posible eliminar un apartado que tiene productos'; 
	END IF;
END;
$$;


ALTER FUNCTION public.elim_apartado(ideap character varying) OWNER TO postgres;

--
-- Name: elim_apdet(character varying, public.id_producto_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_apdet(ideap character varying, idepro public.id_producto_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE cant INTEGER; BEGIN SELECT cantidad INTO cant FROM apartado_detalle WHERE id_apartado=ideap AND id_producto=idepro; PERFORM act_productos_inventario(FALSE, idepro, cant); DELETE FROM apartado_detalle WHERE id_apartado=ideap AND id_producto=idepro; END; $$;


ALTER FUNCTION public.elim_apdet(ideap character varying, idepro public.id_producto_dominio) OWNER TO postgres;

--
-- Name: elim_compra(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_compra(idecom character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	mon NUMERIC(10,2);
BEGIN
	SELECT monto INTO mon FROM compras WHERE id_compra=idecom;
	IF mon=0 THEN
		DELETE FROM compras WHERE id_compra=idecom;
	ELSE
		RAISE EXCEPTION 'No es posible eliminar una compra con un monto mayor a 0'; 
	END IF;
END;
$$;


ALTER FUNCTION public.elim_compra(idecom character varying) OWNER TO postgres;

--
-- Name: elim_compra_prod(character varying, public.id_producto_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_compra_prod(idecom character varying, idepro public.id_producto_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE cant INTEGER; BEGIN SELECT cantidad INTO cant FROM compra_producto WHERE id_compra=idecom AND id_producto=idepro; PERFORM act_productos_inventario(FALSE, idepro, cant); DELETE FROM compra_producto WHERE id_compra=idecom AND id_producto=idepro; END; $$;


ALTER FUNCTION public.elim_compra_prod(idecom character varying, idepro public.id_producto_dominio) OWNER TO postgres;

--
-- Name: elim_devolucion(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_devolucion(idedev character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	mon NUMERIC(10,2);
BEGIN
	SELECT monto INTO mon FROM devolucion_ventas WHERE id_devolucion=idedev;
	IF mon=0 THEN
		DELETE FROM devolucion_ventas WHERE id_devolucion=idedev;
	ELSE
		RAISE EXCEPTION 'No es posible eliminar una devolucion con un monto mayor a 0'; 
	END IF;
END;
$$;


ALTER FUNCTION public.elim_devolucion(idedev character varying) OWNER TO postgres;

--
-- Name: elim_devolucion_prod(character varying, public.id_producto_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.elim_devolucion_prod(idedev character varying, idepro public.id_producto_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE cant INTEGER; ras VARCHAR(50); BEGIN SELECT cantidad, motivo INTO cant, ras FROM devolucion_ventas_detalle WHERE id_devolucion=idedev AND id_producto=idepro; IF ras='Otro motivo' THEN PERFORM act_productos_inventario(FALSE, idepro, cant); END IF; DELETE FROM devolucion_ventas_detalle WHERE id_devolucion=idedev AND id_producto=idepro; END; $$;


ALTER FUNCTION public.elim_devolucion_prod(idedev character varying, idepro public.id_producto_dominio) OWNER TO postgres;

--
-- Name: eliminar_prod(public.id_producto_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.eliminar_prod(idepro public.id_producto_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE cant INTEGER; BEGIN SELECT cantidad_prod INTO cant FROM venta_temp WHERE id_producto=idepro; PERFORM act_productos_inventario(TRUE, idepro, cant); DELETE FROM venta_temp WHERE id_producto=idepro; END; $$;


ALTER FUNCTION public.eliminar_prod(idepro public.id_producto_dominio) OWNER TO postgres;

--
-- Name: entregar_ap(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.entregar_ap(ideap character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	est "estadoValido";
	idem "curp_dominio";
BEGIN
	SELECT estado INTO est FROM apartado WHERE id_apartado=ideap;
	IF est='Cancelado' THEN
		RAISE EXCEPTION 'El apartado ya ha sido cancelado';
	ELSIF est='Entregado' THEN
		RAISE EXCEPTION 'El apartado ya ha sido entregado';
	ELSE
		SELECT id_empleado INTO idem FROM apartado WHERE id_apartado=ideap;
		UPDATE apartado SET estado='Entregado' WHERE id_apartado=ideap;
		PERFORM reg_apartado_venta(ideap, idem);
	END IF;
END;
$$;


ALTER FUNCTION public.entregar_ap(ideap character varying) OWNER TO postgres;

--
-- Name: estado_resultados(numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.estado_resultados(inv_ini numeric) RETURNS TABLE(total_ventas numeric, total_devoluciones numeric, inventario_inicial numeric, total_compras numeric, total_gastos numeric, inventario_final numeric, total_otras_ganancias numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
	anio VARCHAR(4);
	ini DATE;
	fin DATE;
	inv_fin NUMERIC(10,2);
BEGIN
	fin := CURRENT_DATE;
    anio := TO_CHAR(fin, 'YYYY');
    ini := CAST(anio || '-01-01' AS DATE);
    SELECT COALESCE(SUM(m), 0) INTO inv_fin FROM (
        SELECT p.id_producto, p.cantidad*precio_adquirido AS m
        FROM producto AS p, compras NATURAL JOIN compra_producto AS cp
        WHERE p.id_producto=cp.id_producto 
        AND fecha_compra BETWEEN ini AND fin
    ) AS sub;
    RETURN QUERY
    SELECT
        COALESCE((SELECT SUM(total_venta) FROM venta WHERE fecha_venta BETWEEN ini AND fin), 0) AS total_ventas,
        COALESCE((SELECT SUM(monto) FROM devolucion_ventas WHERE fecha_devolucion BETWEEN ini AND fin), 0) AS total_devoluciones,
        COALESCE((SELECT inv_ini), 0) AS inventario_inicial,
        COALESCE((SELECT SUM(monto) FROM compras WHERE fecha_compra BETWEEN ini AND fin), 0) AS total_compras,
        COALESCE((SELECT SUM(monto) FROM gastos WHERE fecha_gasto BETWEEN ini AND fin), 0) AS total_gastos,
        COALESCE((SELECT inv_fin), 0) AS inventario_final,
        COALESCE((SELECT SUM(monto) FROM otras_ganancias WHERE fecha_otras_ganancias BETWEEN ini AND fin), 0) AS total_otras_ganancias;
END;
$$;


ALTER FUNCTION public.estado_resultados(inv_ini numeric) OWNER TO postgres;

--
-- Name: fn_kardex_producto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_kardex_producto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tipo VARCHAR(20);
    v_ref  VARCHAR(15);
    v_emp  CHAR(18);
BEGIN
    IF NEW.cantidad IS DISTINCT FROM OLD.cantidad THEN

        v_tipo := NULLIF(current_setting('kardex.tipo', true), '');
        v_ref  := NULLIF(current_setting('kardex.referencia', true), '');
        v_emp  := NULLIF(current_setting('kardex.empleado', true), '')::CHAR(18);

        -- Aumento sin tipo explícito = reversión interna del SP (p.ej. cambio de
        -- cantidad en carrito). Elimina el kardex del decrement previo y no registra.
        IF NEW.cantidad > OLD.cantidad AND v_tipo IS NULL THEN
            DELETE FROM kardex
            WHERE id_producto = NEW.id_producto
              AND existencia_posterior = OLD.cantidad
              AND fecha >= (NOW() - INTERVAL '2 seconds');
            RETURN NEW;
        END IF;

        -- Si no viene tipo en la sesión, infiere por dirección del cambio
        IF v_tipo IS NULL THEN
            v_tipo := CASE WHEN NEW.cantidad < OLD.cantidad THEN 'Venta' ELSE 'Compra' END;
        END IF;

        INSERT INTO kardex (
            id_producto, tipo_movimiento, cantidad,
            existencia_anterior, existencia_posterior,
            referencia, id_empleado
        ) VALUES (
            NEW.id_producto, v_tipo, NEW.cantidad - OLD.cantidad,
            OLD.cantidad, NEW.cantidad,
            v_ref, v_emp
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_kardex_producto() OWNER TO postgres;

--
-- Name: gen_id_cotizacion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.gen_id_cotizacion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.id_cotizacion := 'COT-' || LPAD(nextval('cotizacion_seq')::TEXT, 10, '0');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.gen_id_cotizacion() OWNER TO postgres;

--
-- Name: generar_id_producto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generar_id_producto() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    nuevo_id VARCHAR(13);
BEGIN
    nuevo_id := 'P-' || LPAD(nextval('id_producto_seq')::TEXT, 11, '0');
    RETURN nuevo_id;
END;
$$;


ALTER FUNCTION public.generar_id_producto() OWNER TO postgres;

--
-- Name: hay_pocos_prod(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.hay_pocos_prod() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	cant INTEGER;
BEGIN
	SELECT COUNT(id_producto) INTO cant FROM producto WHERE cantidad<=12;
	IF cant=0 THEN
		RETURN FALSE;
	ELSE
		RETURN TRUE;
	END IF;
END;
$$;


ALTER FUNCTION public.hay_pocos_prod() OWNER TO postgres;

--
-- Name: ide_emp(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ide_emp(neim character varying) RETURNS public.curp_dominio
    LANGUAGE plpgsql
    AS $$
DECLARE
	idemp "curp_dominio";
BEGIN
	SELECT id_empleado INTO idemp FROM empleado WHERE nombre=neim;
	RETURN idemp;
END;
$$;


ALTER FUNCTION public.ide_emp(neim character varying) OWNER TO postgres;

--
-- Name: ide_emp(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ide_emp(userr character varying, contra character varying) RETURNS TABLE(ide public.curp_dominio, neim character varying, pues public."puestoValido", tel character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
	con VARCHAR(20);
BEGIN
	SELECT contrasenia INTO con FROM empleado WHERE usuario=userr AND estatus='Activo';
	IF con=contra THEN
		RETURN QUERY
		SELECT
			(SELECT id_empleado FROM empleado WHERE usuario=userr AND estatus='Activo') AS ide,
			(SELECT nombre FROM empleado WHERE usuario=userr AND estatus='Activo') AS neim,
			(SELECT puesto FROM empleado WHERE usuario=userr AND estatus='Activo') AS pues,
			(SELECT telefono FROM empleado WHERE usuario=userr AND estatus='Activo') AS tel;
	ELSE
		RAISE EXCEPTION 'Contraseña incorrecta';
	END IF;
END;
$$;


ALTER FUNCTION public.ide_emp(userr character varying, contra character varying) OWNER TO postgres;

--
-- Name: inactivar_cliente(public.curp_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.inactivar_cliente(idecli public.curp_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF idecli='XAXX111111HCCXXXX0' THEN
		RAISE EXCEPTION 'No es posible inactivar a el Cliente Genérico';
	ELSE
		UPDATE cliente SET estatus='Inactivo' WHERE id_cliente=idecli;
	END IF;
END;
$$;


ALTER FUNCTION public.inactivar_cliente(idecli public.curp_dominio) OWNER TO postgres;

--
-- Name: inactivar_cliente(public.curp_dominio, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.inactivar_cliente(idecli public.curp_dominio, inactivar boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF idecli='XAXX111111HCCXXXX0' THEN
		RAISE EXCEPTION 'No es posible inactivar al Cliente Genérico';
	ELSE
		IF inactivar=TRUE THEN
			UPDATE cliente SET estatus='Inactivo' WHERE id_cliente=idecli;
		ELSE
			UPDATE cliente SET estatus='Activo' WHERE id_cliente=idecli;
		END IF;
	END IF;
END;
$$;


ALTER FUNCTION public.inactivar_cliente(idecli public.curp_dominio, inactivar boolean) OWNER TO postgres;

--
-- Name: inactivar_empleado(public.curp_dominio, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.inactivar_empleado(idemp public.curp_dominio, inact boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
	cant INTEGER;
	usur VARCHAR(20);
BEGIN
	SELECT COUNT(id_empleado) INTO cant FROM empleado WHERE id_empleado=idemp;
    IF cant=0 THEN
        RAISE EXCEPTION 'No se encontró al empleado';
    ELSE
		SELECT usuario INTO usur FROM empleado WHERE id_empleado=idemp;
        IF inact=TRUE THEN
			EXECUTE FORMAT('ALTER ROLE %I WITH NOLOGIN', usur);
			UPDATE empleado SET estatus='Inactivo' WHERE id_empleado=idemp;
		ELSE
			EXECUTE FORMAT('ALTER ROLE %I WITH LOGIN', usur);
			UPDATE empleado SET estatus='Activo' WHERE id_empleado=idemp;
		END IF;
    END IF;
END;
$$;


ALTER FUNCTION public.inactivar_empleado(idemp public.curp_dominio, inact boolean) OWNER TO postgres;

--
-- Name: realizar_venta(public.curp_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.realizar_venta(idemp public.curp_dominio) RETURNS character varying
    LANGUAGE plpgsql
    AS $$ DECLARE idevent VARCHAR(15); ideprod id_producto_dominio; suma NUMERIC(10,2); cp INTEGER; pd NUMERIC(10,2); pt NUMERIC(10,2); tv "tipoVenta"; BEGIN INSERT INTO venta(id_empleado, total_venta) VALUES(idemp, -1); SELECT id_venta INTO idevent FROM venta WHERE total_venta=-1; FOR ideprod IN SELECT id_producto FROM venta_temp LOOP INSERT INTO venta_detalle(id_venta, id_producto) VALUES (idevent, ideprod); SELECT cantidad_prod, precio_dado, precio_total, tipo_venta INTO cp, pd, pt, tv FROM venta_temp WHERE id_producto=ideprod; UPDATE venta_detalle SET cantidad_producto=cp, precio_dado=pd, precio_total=pt, tipo_venta=tv WHERE id_venta=idevent AND id_producto=ideprod; END LOOP; SELECT SUM(precio_total) INTO suma FROM venta_detalle WHERE id_venta=idevent; UPDATE venta SET total_venta=suma WHERE id_venta=idevent; TRUNCATE TABLE venta_temp; RETURN idevent; END; $$;


ALTER FUNCTION public.realizar_venta(idemp public.curp_dominio) OWNER TO postgres;

--
-- Name: realizar_venta(public.curp_dominio, public.curp_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.realizar_venta(idemp public.curp_dominio, idecli public.curp_dominio) RETURNS character varying
    LANGUAGE plpgsql
    AS $$ DECLARE idevent VARCHAR(15); ideprod id_producto_dominio; suma NUMERIC(10,2); cp INTEGER; pd NUMERIC(10,2); pt NUMERIC(10,2); tv "tipoVenta"; BEGIN INSERT INTO venta(id_empleado, total_venta, id_cliente) VALUES(idemp, -1, idecli); SELECT id_venta INTO idevent FROM venta WHERE total_venta=-1; FOR ideprod IN SELECT id_producto FROM venta_temp LOOP INSERT INTO venta_detalle(id_venta, id_producto) VALUES (idevent, ideprod); SELECT cantidad_prod, precio_dado, precio_total, tipo_venta INTO cp, pd, pt, tv FROM venta_temp WHERE id_producto=ideprod; UPDATE venta_detalle SET cantidad_producto=cp, precio_dado=pd, precio_total=pt, tipo_venta=tv WHERE id_venta=idevent AND id_producto=ideprod; END LOOP; SELECT SUM(precio_total) INTO suma FROM venta_detalle WHERE id_venta=idevent; UPDATE venta SET total_venta=suma WHERE id_venta=idevent; TRUNCATE TABLE venta_temp; RETURN idevent; END; $$;


ALTER FUNCTION public.realizar_venta(idemp public.curp_dominio, idecli public.curp_dominio) OWNER TO postgres;

--
-- Name: reg_apartado(public.curp_dominio, public.curp_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_apartado(idemp public.curp_dominio, idecli public.curp_dominio) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
	ideap VARCHAR(15);
BEGIN
	INSERT INTO apartado(id_empleado, id_cliente, cantidad_dada, cantidad_faltante, cantidad_total)
	VALUES(idemp, idecli, 0, 0, -111);
	SELECT id_apartado INTO ideap FROM apartado WHERE cantidad_total=-111;
	UPDATE apartado SET cantidad_total=0 WHERE id_apartado=ideap;
	RETURN ideap;
END;
$$;


ALTER FUNCTION public.reg_apartado(idemp public.curp_dominio, idecli public.curp_dominio) OWNER TO postgres;

--
-- Name: reg_apartado_venta(character varying, public.curp_dominio); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_apartado_venta(idapart character varying, idemp public.curp_dominio) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE idevent VARCHAR(15); ideprod id_producto_dominio; suma NUMERIC(10,2); cp INTEGER; pd NUMERIC(10,2); pt NUMERIC(10,2); tv "tipoVenta"; BEGIN INSERT INTO venta(id_empleado, total_venta) VALUES(idemp, -1); SELECT id_venta INTO idevent FROM venta WHERE total_venta=-1; FOR ideprod IN SELECT id_producto FROM apartado_detalle WHERE id_apartado=idapart LOOP INSERT INTO venta_detalle(id_venta, id_producto) VALUES (idevent, ideprod); SELECT cantidad, precio_unitario, precio_total, tipo INTO cp, pd, pt, tv FROM apartado_detalle WHERE id_producto=ideprod AND id_apartado=idapart; UPDATE venta_detalle SET cantidad_producto=cp, precio_dado=pd, precio_total=pt, tipo_venta=tv WHERE id_venta=idevent AND id_producto=ideprod; END LOOP; SELECT SUM(precio_total) INTO suma FROM venta_detalle WHERE id_venta=idevent; UPDATE venta SET total_venta=suma WHERE id_venta=idevent; END; $$;


ALTER FUNCTION public.reg_apartado_venta(idapart character varying, idemp public.curp_dominio) OWNER TO postgres;

--
-- Name: reg_apdet(character varying, public.id_producto_dominio, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_apdet(ideapar character varying, idepro public.id_producto_dominio, cant integer, acum boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE num INTEGER; ka INTEGER; cantt INTEGER; BEGIN SELECT cantidad INTO ka FROM producto WHERE id_producto=idepro; IF ka >= cant THEN SELECT COUNT(id_producto) INTO num FROM apartado_detalle WHERE id_apartado=ideapar AND id_producto=idepro; IF num=0 THEN INSERT INTO apartado_detalle(id_apartado, id_producto, cantidad) VALUES(ideapar, idepro, cant); ELSE SELECT cantidad INTO cantt FROM apartado_detalle WHERE id_apartado=ideapar AND id_producto=idepro; PERFORM act_productos_inventario(TRUE, idepro, cantt); IF acum=TRUE THEN cant := cantt + cant; END IF; UPDATE apartado_detalle SET cantidad=cant WHERE id_apartado=ideapar AND id_producto=idepro; END IF; SELECT SUM(precio_total) INTO num FROM apartado_detalle WHERE id_apartado=ideapar; UPDATE apartado SET cantidad_total=num WHERE id_apartado=ideapar; PERFORM act_productos_inventario(FALSE, idepro, cant); ELSE RAISE EXCEPTION 'No hay suficiente cantidad de productos'; END IF; END; $$;


ALTER FUNCTION public.reg_apdet(ideapar character varying, idepro public.id_producto_dominio, cant integer, acum boolean) OWNER TO postgres;

--
-- Name: reg_compra(public.curp_dominio, character varying, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_compra(idemp public.curp_dominio, des character varying, mon numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
	idecom VARCHAR(15);
BEGIN
	INSERT INTO compras(id_empleado, descripcion, monto) VALUES(idemp, des, -111);
	SELECT id_compra INTO idecom FROM compras WHERE monto=-111;
	UPDATE compras SET monto=mon WHERE id_compra=idecom;
	RETURN idecom;
END;
$$;


ALTER FUNCTION public.reg_compra(idemp public.curp_dominio, des character varying, mon numeric) OWNER TO postgres;

--
-- Name: reg_compra_prod(character varying, public.id_producto_dominio, numeric, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_compra_prod(idecom character varying, idepro public.id_producto_dominio, prec numeric, cant integer, acum boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE num INTEGER; cantt INTEGER; ka INTEGER; cant_t NUMERIC(10,2); precc NUMERIC(10,2); BEGIN SELECT COUNT(id_producto) INTO num FROM producto WHERE id_producto=idepro; IF num=0 THEN RAISE EXCEPTION 'No existe el producto en el inventario'; ELSE SELECT COUNT(id_producto) INTO num FROM compra_producto WHERE id_producto=idepro AND id_compra=idecom; IF num=0 THEN cant_t := cant * prec; INSERT INTO compra_producto VALUES(idecom, idepro, prec, cant, cant_t); ELSE SELECT precio_adquirido, cantidad INTO precc, cantt FROM compra_producto WHERE id_producto=idepro AND id_compra=idecom; PERFORM act_productos_inventario(FALSE, idepro, cantt); IF acum = TRUE THEN cant := cantt + cant; END IF; cant_t := cant * prec; UPDATE compra_producto SET precio_adquirido=prec, cantidad=cant, precio_total=cant_t WHERE id_producto=idepro AND id_compra=idecom; END IF; SELECT SUM(precio_total) INTO cant_t FROM compra_producto WHERE id_compra=idecom; UPDATE compras SET monto=cant_t WHERE id_compra=idecom; PERFORM act_productos_inventario(TRUE, idepro, cant); END IF; END; $$;


ALTER FUNCTION public.reg_compra_prod(idecom character varying, idepro public.id_producto_dominio, prec numeric, cant integer, acum boolean) OWNER TO postgres;

--
-- Name: reg_devolucion(character varying, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_devolucion(ideven character varying, mon numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
	cant INTEGER;
	ided VARCHAR(15);
BEGIN
	SELECT COUNT(id_devolucion) INTO cant FROM devolucion_ventas WHERE id_venta=ideven;
	IF cant=0 THEN
		INSERT INTO devolucion_ventas(id_venta, monto) VALUES(ideven, -111);
		SELECT id_devolucion INTO ided FROM devolucion_ventas WHERE monto=-111;
		UPDATE devolucion_ventas SET monto=mon WHERE id_devolucion=ided;
		RETURN ided;
	ELSE
		RAISE EXCEPTION 'No es posible registrar otra devolución sobre la misma venta, si desea hacerlo debe actualizar la devolución de esa venta';
		RETURN NULL;
	END IF;
END;
$$;


ALTER FUNCTION public.reg_devolucion(ideven character varying, mon numeric) OWNER TO postgres;

--
-- Name: reg_devolucion_prod(character varying, character varying, public.id_producto_dominio, boolean, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_devolucion_prod(idedev character varying, ideve character varying, idepro public.id_producto_dominio, mot boolean, canti integer) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE num INTEGER; cant INTEGER; tot NUMERIC(10,2); rason VARCHAR(50); BEGIN SELECT COUNT(id_producto) INTO num FROM venta_detalle WHERE id_producto=idepro AND id_venta=ideve; IF num=0 THEN RAISE EXCEPTION 'El producto no esta dentro de la id de venta'; ELSE SELECT cantidad_producto, precio_dado INTO cant, tot FROM venta_detalle WHERE id_producto=idepro AND id_venta=ideve; IF canti>cant THEN RAISE EXCEPTION 'No es posible devolver una cantidad mayor a la que se tiene registrada'; ELSE tot := tot * canti; SELECT COUNT(id_producto) INTO num FROM devolucion_ventas_detalle WHERE id_producto=idepro AND id_devolucion=idedev; IF num=0 THEN INSERT INTO devolucion_ventas_detalle(id_devolucion, id_producto, motivo, cantidad, total) VALUES (idedev, idepro, NULL, canti, tot); ELSE SELECT motivo INTO rason FROM devolucion_ventas_detalle WHERE id_producto=idepro AND id_devolucion=idedev; IF rason='Otro motivo' THEN PERFORM act_productos_inventario(FALSE, idepro, canti); END IF; UPDATE devolucion_ventas_detalle SET cantidad=canti, total=tot WHERE id_producto=idepro AND id_devolucion=idedev; END IF; IF mot=TRUE THEN UPDATE devolucion_ventas_detalle SET motivo='El producto estaba en mal estado' WHERE id_producto=idepro AND id_devolucion=idedev; ELSE UPDATE devolucion_ventas_detalle SET motivo='Otro motivo' WHERE id_producto=idepro AND id_devolucion=idedev; PERFORM act_productos_inventario(TRUE, idepro, canti); END IF; END IF; SELECT SUM(total) INTO tot FROM devolucion_ventas_detalle WHERE id_devolucion=idedev; UPDATE devolucion_ventas SET monto=tot WHERE id_devolucion=idedev; END IF; END; $$;


ALTER FUNCTION public.reg_devolucion_prod(idedev character varying, ideve character varying, idepro public.id_producto_dominio, mot boolean, canti integer) OWNER TO postgres;

--
-- Name: reg_empleado(character varying, character varying, public."puestoValido"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reg_empleado(nomb character varying, passwor character varying, puest public."puestoValido") RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	EXECUTE format('CREATE USER %I WITH PASSWORD %L', nomb, passwor);
    IF puest = 'Gerente' THEN
        EXECUTE format('GRANT gerente TO %I', nomb);
    ELSE
        EXECUTE format('GRANT vendedor TO %I', nomb);
    END IF;
END;
$$;


ALTER FUNCTION public.reg_empleado(nomb character varying, passwor character varying, puest public."puestoValido") OWNER TO postgres;

--
-- Name: regresar_productos_inv(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.regresar_productos_inv(ideap character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE idepro id_producto_dominio; cant INTEGER; BEGIN FOR idepro IN SELECT id_producto FROM apartado_detalle WHERE id_apartado=ideap LOOP SELECT cantidad INTO cant FROM apartado_detalle WHERE id_apartado=ideap AND id_producto=idepro; PERFORM act_productos_inventario(TRUE, idepro, cant); END LOOP; END; $$;


ALTER FUNCTION public.regresar_productos_inv(ideap character varying) OWNER TO postgres;

--
-- Name: reporte_diario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reporte_diario() RETURNS TABLE(total_ventas numeric, total_devoluciones numeric, total_compras numeric, total_gastos numeric, total_otras_ganancias numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
	fecha DATE;
	inv_fin NUMERIC(10,2);
BEGIN
	fecha := CURRENT_DATE;
    SELECT COALESCE(SUM(m), 0) INTO inv_fin FROM (
        SELECT p.id_producto, p.cantidad*precio_adquirido AS m
        FROM producto AS p, compras NATURAL JOIN compra_producto AS cp
        WHERE p.id_producto=cp.id_producto 
        AND fecha_compra=fecha
    ) AS sub;
    RETURN QUERY
    SELECT
        COALESCE((SELECT SUM(total_venta) FROM venta WHERE fecha_venta=fecha), 0) AS total_ventas,
        COALESCE((SELECT SUM(monto) FROM devolucion_ventas WHERE fecha_devolucion=fecha), 0) AS total_devoluciones,
        COALESCE((SELECT SUM(monto) FROM compras WHERE fecha_compra=fecha), 0) AS total_compras,
        COALESCE((SELECT SUM(monto) FROM gastos WHERE fecha_gasto=fecha), 0) AS total_gastos,
        COALESCE((SELECT SUM(monto) FROM otras_ganancias WHERE fecha_otras_ganancias=fecha), 0) AS total_otras_ganancias;
END;
$$;


ALTER FUNCTION public.reporte_diario() OWNER TO postgres;

--
-- Name: reporte_diario(date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.reporte_diario(p_fecha date) RETURNS TABLE(total_ventas numeric, total_devoluciones numeric, total_compras numeric, total_gastos numeric, total_otras_ganancias numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
    inv_fin NUMERIC(10,2);
BEGIN
    SELECT COALESCE(SUM(m), 0) INTO inv_fin FROM (
        SELECT p.id_producto, p.cantidad * precio_adquirido AS m
        FROM producto AS p, compras NATURAL JOIN compra_producto AS cp
        WHERE p.id_producto = cp.id_producto
        AND fecha_compra = p_fecha
    ) AS sub;

    RETURN QUERY
    SELECT
        COALESCE((SELECT SUM(total_venta) FROM venta WHERE fecha_venta = p_fecha), 0),
        COALESCE((SELECT SUM(monto) FROM devolucion_ventas WHERE fecha_devolucion = p_fecha), 0),
        COALESCE((SELECT SUM(monto) FROM compras WHERE fecha_compra = p_fecha), 0),
        COALESCE((SELECT SUM(monto) FROM gastos WHERE fecha_gasto = p_fecha), 0),
        COALESCE((SELECT SUM(monto) FROM otras_ganancias WHERE fecha_otras_ganancias = p_fecha), 0);
END;
$$;


ALTER FUNCTION public.reporte_diario(p_fecha date) OWNER TO postgres;

--
-- Name: set_campos_ap(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_ap() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    cantt NUMERIC(10,2);
BEGIN
	NEW.id_apartado := 'A' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_inicio := CURRENT_DATE;
	NEW.fecha_limite := NEW.fecha_inicio + INTERVAL '30 days';
	NEW.estado := 'Vigente';
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_ap() OWNER TO postgres;

--
-- Name: set_campos_apdet(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_apdet() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
	num INTEGER;
	prec NUMERIC(10,2);
BEGIN
	IF NEW.cantidad >= 12 THEN
		SELECT precio_mayoreo INTO prec FROM producto WHERE id_producto=NEW.id_producto;
		NEW.precio_unitario := prec;
		NEW.tipo := 'Mayoreo';
	ELSE
		SELECT precio_menudeo INTO prec FROM producto WHERE id_producto=NEW.id_producto;
		NEW.precio_unitario := prec;
		NEW.tipo := 'Menudeo';
	END IF;
    NEW.precio_total := NEW.precio_unitario * NEW.cantidad;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_apdet() OWNER TO postgres;

--
-- Name: set_campos_compras(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_compras() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.id_compra := 'C' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_compra := CURRENT_DATE;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_compras() OWNER TO postgres;

--
-- Name: set_campos_devv(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_devv() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.id_devolucion := 'D' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_devolucion := CURRENT_DATE;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_devv() OWNER TO postgres;

--
-- Name: set_campos_gstos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_gstos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.id_gasto := 'G' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_gasto := CURRENT_DATE;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_gstos() OWNER TO postgres;

--
-- Name: set_campos_og(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_og() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.id_otras_ganancias := 'O' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_otras_ganancias := CURRENT_DATE;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_og() OWNER TO postgres;

--
-- Name: set_campos_venta(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_campos_venta() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	NEW.id_venta := 'V' || TO_CHAR(NOW(), 'YYYYMMDDHH24MISS');
	NEW.fecha_venta := CURRENT_DATE;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_campos_venta() OWNER TO postgres;

--
-- Name: set_venta_temp(public.id_producto_dominio, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_venta_temp(ideprod public.id_producto_dominio, cant integer, acumular boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$ DECLARE aux INTEGER; cantt INTEGER; num INTEGER; BEGIN SELECT COUNT(id_producto) INTO aux FROM producto WHERE id_producto=ideprod; IF aux=0 THEN RAISE EXCEPTION 'El producto no existe'; ELSE SELECT COUNT(id_producto) INTO num FROM venta_temp WHERE id_producto=ideprod; IF num=0 THEN INSERT INTO venta_temp(id_producto, cantidad_prod) VALUES(ideprod, cant); ELSE IF acumular=TRUE THEN SELECT cantidad_prod INTO cantt FROM venta_temp WHERE id_producto=ideprod; cant := cantt + cant; UPDATE venta_temp SET cantidad_prod=cant WHERE id_producto = ideprod; ELSE UPDATE venta_temp SET cantidad_prod=cant WHERE id_producto = ideprod; END IF; END IF; END IF; END; $$;


ALTER FUNCTION public.set_venta_temp(ideprod public.id_producto_dominio, cant integer, acumular boolean) OWNER TO postgres;

--
-- Name: suma_venta_temp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.suma_venta_temp() RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
	prec NUMERIC(10,2);
BEGIN
	SELECT SUM(precio_total) INTO prec FROM venta_temp;
	IF prec IS NULL THEN
		prec := 0;
	END IF;
	RETURN prec;
END;
$$;


ALTER FUNCTION public.suma_venta_temp() OWNER TO postgres;

--
-- Name: total_caja(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.total_caja(inicio date, fin date) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
declare
	total decimal(20,2);
	apoyo decimal(20,2);
begin
	--Suma de todas las ventas
	SELECT SUM(total_venta) INTO total FROM venta WHERE fecha_venta BETWEEN inicio AND fin;
	--Suma del dinero obtenido de los apartados vigentes
	SELECT SUM(cantidad_dada) INTO apoyo FROM apartado WHERE estado='Vigente';
	total := total+apoyo;
	apoyo:=0;
	--Suma del monto de otras ganancias obtenidas
	SELECT SUM(monto) INTO apoyo FROM otras_ganancias WHERE fecha_otras_ganancias BETWEEN inicio AND fin;
	total:= total+apoyo;
	apoyo:=0;
	--Suma del dinero gastado en la compra de productos
	SELECT SUM(precio_total) INTO apoyo FROM compra_producto;
	total:= total - apoyo;
	apoyo:=0;
	--Suma de las devoluciones sobre ventas
	SELECT SUM(monto) INTO apoyo FROM devolucion_ventas WHERE fecha_devolucion BETWEEN inicio AND fin;
	total:= total - apoyo;
	apoyo:=0;
	--Suma de los gastos hechos en el establecimiento
	SELECT SUM(monto) INTO apoyo FROM gastos WHERE fecha_gasto BETWEEN inicio AND fin;
	total:= total - apoyo;
	apoyo:=0;
	return total;
end;
$$;


ALTER FUNCTION public.total_caja(inicio date, fin date) OWNER TO postgres;

--
-- Name: total_clientes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.total_clientes() RETURNS numeric
    LANGUAGE plpgsql
    AS $$
declare
	clientes decimal(20,2);
	renglon record;
begin
	clientes := 0;
	for renglon in (SELECT cantidad_faltante FROM apartado)
		loop
		if renglon.cantidad_faltante > 0 then
			clientes:= clientes + renglon.cantidad_faltante;
		end if;
		end loop;
	return clientes;
end;
$$;


ALTER FUNCTION public.total_clientes() OWNER TO postgres;

--
-- Name: total_inventario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.total_inventario() RETURNS numeric
    LANGUAGE plpgsql
    AS $$
declare
	inventario decimal(20,2);
	ayuda decimal(20,2);
	renglon record;
begin
	inventario:=0;
	for renglon in SELECT id_producto FROM producto
		loop
		if renglon.id_producto in (SELECT id_producto FROM compra_producto) then 
			SELECT (cantidad*precio_adquirido) INTO ayuda 
			FROM compra_producto AS cp WHERE cp.id_producto=renglon.id_producto;
			inventario := inventario+ayuda;
		else 
			SELECT (cantidad*precio_menudeo) INTO ayuda 
			FROM producto AS p WHERE p.id_producto=renglon.id_producto;
			inventario:=inventario+ayuda;
		end if;
		end loop;
	return inventario;
end;
$$;


ALTER FUNCTION public.total_inventario() OWNER TO postgres;

--
-- Name: validar_id_producto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.validar_id_producto() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$ BEGIN IF NEW.id_producto IS NULL OR trim(NEW.id_producto) = '' THEN RAISE EXCEPTION 'El ID del producto no puede estar vacío'; END IF; IF length(NEW.id_producto) < 3 OR length(NEW.id_producto) > 50 THEN RAISE EXCEPTION 'El ID del producto debe tener entre 3 y 50 caracteres'; END IF; IF NEW.id_producto !~ '^[A-Za-z0-9_-]+$' THEN RAISE EXCEPTION 'El ID del producto solo puede contener letras, números, guiones (-) y guión bajo (_)'; END IF; RETURN NEW; END; $_$;


ALTER FUNCTION public.validar_id_producto() OWNER TO postgres;

--
-- Name: verif_exist_insert(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_exist_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ DECLARE neim VARCHAR(50); praise NUMERIC(10,2); cant INTEGER; BEGIN SELECT cantidad INTO cant FROM producto WHERE id_producto=NEW.id_producto; IF cant >= NEW.cantidad_prod THEN SELECT nombre INTO neim FROM producto WHERE id_producto=NEW.id_producto; NEW.nombre_p := neim; IF NEW.cantidad_prod >= 12 THEN SELECT precio_mayoreo INTO praise FROM producto WHERE id_producto=NEW.id_producto; NEW.precio_dado := praise; NEW.tipo_venta := 'Mayoreo'; ELSE SELECT precio_menudeo INTO praise FROM producto WHERE id_producto=NEW.id_producto; NEW.precio_dado := praise; NEW.tipo_venta := 'Menudeo'; END IF; NEW.precio_total := NEW.precio_dado * NEW.cantidad_prod; PERFORM act_productos_inventario(FALSE, NEW.id_producto, NEW.cantidad_prod); RETURN NEW; ELSE RAISE EXCEPTION 'No hay suficiente cantidad de productos'; END IF; END; $$;


ALTER FUNCTION public.verif_exist_insert() OWNER TO postgres;

--
-- Name: verif_exist_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_exist_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    praise NUMERIC(10,2);
    cant   INTEGER;
BEGIN
    SELECT cantidad INTO cant FROM producto WHERE id_producto = NEW.id_producto;
    cant := cant + OLD.cantidad_prod;

    IF cant >= NEW.cantidad_prod THEN
        PERFORM act_productos_inventario(TRUE, NEW.id_producto, OLD.cantidad_prod);

        IF NEW.cantidad_prod >= 12 THEN
            SELECT precio_mayoreo INTO praise FROM producto WHERE id_producto = NEW.id_producto;
            NEW.precio_dado  := praise;
            NEW.tipo_venta   := 'Mayoreo';
        ELSE
            SELECT precio_menudeo INTO praise FROM producto WHERE id_producto = NEW.id_producto;
            NEW.precio_dado  := praise;
            NEW.tipo_venta   := 'Menudeo';
        END IF;

        -- Aplicar descuento al calcular precio_total
        NEW.precio_total := ROUND(NEW.precio_dado * NEW.cantidad_prod * (1.0 - NEW.descuento_pct / 100.0), 2);

        PERFORM act_productos_inventario(FALSE, NEW.id_producto, NEW.cantidad_prod);
        RETURN NEW;
    ELSE
        RAISE EXCEPTION 'No hay suficiente cantidad de productos';
    END IF;
END;
$$;


ALTER FUNCTION public.verif_exist_update() OWNER TO postgres;

--
-- Name: verif_puesto(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_puesto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    num INTEGER;
BEGIN
	IF NEW.puesto='gerente' THEN
		IF (TG_OP = 'INSERT') THEN
			SELECT COUNT(id_empleado) INTO num FROM empleado WHERE puesto='gerente';
		ELSIF (TG_OP = 'UPDATE') THEN
			SELECT COUNT(id_empleado) INTO num FROM empleado WHERE puesto='gerente' AND id_empleado!=OLD.id_empleado;
		END IF;
        IF num=0 THEN
            RETURN NEW;
        ELSE
            RAISE EXCEPTION 'Sólo puede existir un único Gerente';
            RETURN NULL;
        END IF;
	ELSE
		IF (TG_OP = 'INSERT') THEN
			PERFORM reg_empleado(NEW.usuario, NEW.contrasenia, NEW.puesto);
		END IF;
		RETURN NEW;
    END IF;
END;
$$;


ALTER FUNCTION public.verif_puesto() OWNER TO postgres;

--
-- Name: verif_tel_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_tel_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    cant INTEGER;
BEGIN
	IF (TG_OP = 'INSERT') THEN
		SELECT COUNT(id_cliente) INTO cant FROM cliente WHERE telefono=NEW.telefono;
		NEW.estatus := 'Activo';
	ELSIF (TG_OP = 'UPDATE') THEN
		SELECT COUNT(id_cliente) INTO cant FROM cliente WHERE telefono=NEW.telefono AND id_cliente!=OLD.id_cliente;
	END IF;
    IF cant=0 THEN
        RETURN NEW;
    ELSE
        RAISE EXCEPTION 'Sólo puede existir un único número telefónico';
        RETURN NULL;
    END IF;
END;
$$;


ALTER FUNCTION public.verif_tel_c() OWNER TO postgres;

--
-- Name: verif_tel_e(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_tel_e() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    cant INTEGER;
BEGIN
	IF (TG_OP = 'INSERT') THEN
		SELECT COUNT(id_empleado) INTO cant FROM empleado WHERE telefono=NEW.telefono;
		NEW.estatus := 'Activo';
	ELSIF (TG_OP = 'UPDATE') THEN
		SELECT COUNT(id_empleado) INTO cant FROM empleado WHERE telefono=NEW.telefono AND id_empleado!=OLD.id_empleado;
	END IF;
	IF cant=0 THEN
        RETURN NEW;
    ELSE
        RAISE EXCEPTION 'Sólo puede existir un único número telefónico';
        RETURN NULL;
    END IF;
END;
$$;


ALTER FUNCTION public.verif_tel_e() OWNER TO postgres;

--
-- Name: verif_user(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verif_user(userr character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
	num INTEGER;
BEGIN
	SELECT COUNT(id_empleado) INTO num FROM empleado WHERE usuario=userr;
	IF num=0 THEN
		RETURN FALSE;
	ELSE
		RETURN TRUE;
	END IF;
END;
$$;


ALTER FUNCTION public.verif_user(userr character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: apartado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apartado (
    id_apartado character varying(15) NOT NULL,
    id_empleado public.curp_dominio,
    id_cliente public.curp_dominio,
    fecha_inicio date,
    fecha_limite date,
    cantidad_dada numeric(10,2),
    cantidad_faltante numeric(10,2),
    cantidad_total numeric(10,2),
    estado public."estadoValido"
);


ALTER TABLE public.apartado OWNER TO postgres;

--
-- Name: apartado_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.apartado_detalle (
    id_apartado character varying(15),
    id_producto public.id_producto_dominio,
    cantidad integer,
    precio_unitario numeric(10,2),
    precio_total numeric(10,2),
    tipo public."tipoVenta"
);


ALTER TABLE public.apartado_detalle OWNER TO postgres;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(255),
    estatus character varying(10) DEFAULT 'Activo'::character varying,
    CONSTRAINT categoria_estatus_check CHECK (((estatus)::text = ANY (ARRAY[('Activo'::character varying)::text, ('Inactivo'::character varying)::text])))
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_id_categoria_seq OWNER TO postgres;

--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_id_categoria_seq OWNED BY public.categoria.id_categoria;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id_cliente public.curp_dominio NOT NULL,
    nombre character varying(50),
    telefono character varying(10),
    estatus public."estatusValido" DEFAULT 'Activo'::public."estatusValido",
    CONSTRAINT verif_tel CHECK ((length((telefono)::text) = 10))
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: compra_producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compra_producto (
    id_compra character varying(15),
    id_producto public.id_producto_dominio,
    cantidad integer,
    precio_adquirido numeric(10,2),
    precio_total numeric(10,2)
);


ALTER TABLE public.compra_producto OWNER TO postgres;

--
-- Name: compras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compras (
    id_compra character varying(15) NOT NULL,
    id_empleado public.curp_dominio,
    fecha_compra date,
    descripcion character varying(100),
    monto numeric(10,2),
    id_proveedor integer
);


ALTER TABLE public.compras OWNER TO postgres;

--
-- Name: cotizacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cotizacion (
    id_cotizacion character varying(15) NOT NULL,
    fecha_cotizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_empleado character(18),
    id_cliente character(18),
    total_cotizacion numeric(10,2),
    estatus character varying(20) DEFAULT 'Pendiente'::character varying,
    id_venta_convertida character varying(15),
    fecha_vigencia date,
    notas text
);


ALTER TABLE public.cotizacion OWNER TO postgres;

--
-- Name: cotizacion_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cotizacion_detalle (
    id_cotizacion_detalle integer NOT NULL,
    id_cotizacion character varying(15),
    id_producto character varying(50),
    nombre_p character varying(50),
    cantidad integer,
    tipo_venta character varying(10),
    precio_dado numeric(10,2),
    descuento_pct numeric(5,2) DEFAULT 0,
    precio_total numeric(10,2)
);


ALTER TABLE public.cotizacion_detalle OWNER TO postgres;

--
-- Name: cotizacion_detalle_id_cotizacion_detalle_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cotizacion_detalle_id_cotizacion_detalle_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cotizacion_detalle_id_cotizacion_detalle_seq OWNER TO postgres;

--
-- Name: cotizacion_detalle_id_cotizacion_detalle_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cotizacion_detalle_id_cotizacion_detalle_seq OWNED BY public.cotizacion_detalle.id_cotizacion_detalle;


--
-- Name: cotizacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cotizacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cotizacion_seq OWNER TO postgres;

--
-- Name: cotizacion_temp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cotizacion_temp (
    id_producto character varying(50),
    nombre_p character varying(50),
    cantidad_prod integer,
    tipo_venta character varying(10),
    precio_dado numeric(10,2),
    precio_total numeric(10,2),
    descuento_pct numeric(5,2) DEFAULT 0
);


ALTER TABLE public.cotizacion_temp OWNER TO postgres;

--
-- Name: devolucion_ventas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devolucion_ventas (
    id_devolucion character varying(15) NOT NULL,
    id_venta character varying(15),
    fecha_devolucion date,
    monto numeric(10,2)
);


ALTER TABLE public.devolucion_ventas OWNER TO postgres;

--
-- Name: devolucion_ventas_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devolucion_ventas_detalle (
    id_devolucion character varying(15),
    id_producto public.id_producto_dominio,
    motivo character varying(50),
    cantidad integer,
    total numeric(10,2)
);


ALTER TABLE public.devolucion_ventas_detalle OWNER TO postgres;

--
-- Name: empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empleado (
    id_empleado public.curp_dominio NOT NULL,
    nombre character varying(50),
    puesto public."puestoValido",
    telefono character varying(10),
    usuario character varying(20),
    contrasenia character varying(20),
    estatus public."estatusValido" DEFAULT 'Activo'::public."estatusValido",
    CONSTRAINT verif_te CHECK ((length((telefono)::text) = 10))
);


ALTER TABLE public.empleado OWNER TO postgres;

--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    id integer DEFAULT 1 NOT NULL,
    nombre character varying(100) DEFAULT 'Mi Empresa'::character varying NOT NULL,
    razon_social character varying(150),
    rfc character varying(13),
    telefono character varying(20),
    correo character varying(100),
    direccion character varying(200),
    ciudad character varying(100),
    estado character varying(100),
    cp character varying(10),
    mensaje_ticket character varying(200) DEFAULT 'Muchas gracias por su compra.'::character varying,
    logo_ruta character varying(255),
    CONSTRAINT empresa_id_check CHECK ((id = 1))
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: forma_pago_venta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forma_pago_venta (
    id_venta character varying(15) NOT NULL,
    forma_pago character varying(20) NOT NULL,
    monto numeric(10,2),
    CONSTRAINT forma_pago_venta_forma_pago_check CHECK (((forma_pago)::text = ANY (ARRAY[('Efectivo'::character varying)::text, ('Transferencia'::character varying)::text, ('Tarjeta'::character varying)::text, ('Otro'::character varying)::text])))
);


ALTER TABLE public.forma_pago_venta OWNER TO postgres;

--
-- Name: gastos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gastos (
    id_gasto character varying(15),
    id_empleado public.curp_dominio,
    fecha_gasto date,
    descripcion character varying(50),
    monto numeric(10,2)
);


ALTER TABLE public.gastos OWNER TO postgres;

--
-- Name: id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id_producto_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 99999999999
    CACHE 1;


ALTER SEQUENCE public.id_producto_seq OWNER TO postgres;

--
-- Name: kardex; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kardex (
    id_kardex integer NOT NULL,
    id_producto character varying(50),
    fecha timestamp without time zone DEFAULT now(),
    tipo_movimiento character varying(20),
    cantidad integer NOT NULL,
    existencia_anterior integer NOT NULL,
    existencia_posterior integer NOT NULL,
    referencia character varying(15),
    id_empleado character(18),
    CONSTRAINT kardex_tipo_movimiento_check CHECK (((tipo_movimiento)::text = ANY (ARRAY[('Venta'::character varying)::text, ('Compra'::character varying)::text, ('Devolucion'::character varying)::text, ('Ajuste'::character varying)::text])))
);


ALTER TABLE public.kardex OWNER TO postgres;

--
-- Name: kardex_id_kardex_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kardex_id_kardex_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.kardex_id_kardex_seq OWNER TO postgres;

--
-- Name: kardex_id_kardex_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kardex_id_kardex_seq OWNED BY public.kardex.id_kardex;


--
-- Name: lista_precios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lista_precios (
    id_lista integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion character varying(150),
    estatus character varying(10) DEFAULT 'Activo'::character varying
);


ALTER TABLE public.lista_precios OWNER TO postgres;

--
-- Name: lista_precios_id_lista_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lista_precios_id_lista_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lista_precios_id_lista_seq OWNER TO postgres;

--
-- Name: lista_precios_id_lista_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lista_precios_id_lista_seq OWNED BY public.lista_precios.id_lista;


--
-- Name: otras_ganancias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otras_ganancias (
    id_otras_ganancias character varying(15) NOT NULL,
    descripcion character varying(100),
    monto numeric(10,2),
    fecha_otras_ganancias date
);


ALTER TABLE public.otras_ganancias OWNER TO postgres;

--
-- Name: producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.producto (
    id_producto public.id_producto_dominio NOT NULL,
    nombre character varying(50),
    cantidad integer,
    precio_mayoreo numeric(10,2),
    precio_menudeo numeric(10,2),
    id_categoria integer,
    max_descuento numeric(5,2) DEFAULT 100 NOT NULL
);


ALTER TABLE public.producto OWNER TO postgres;

--
-- Name: producto_precio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.producto_precio (
    id_producto character varying(50) NOT NULL,
    id_lista integer NOT NULL,
    precio numeric(10,2) NOT NULL
);


ALTER TABLE public.producto_precio OWNER TO postgres;

--
-- Name: proveedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proveedor (
    id_proveedor integer NOT NULL,
    nombre character varying(150) NOT NULL,
    telefono character varying(15),
    email character varying(100),
    direccion character varying(255),
    estatus character varying(10) DEFAULT 'Activo'::character varying,
    CONSTRAINT proveedor_estatus_check CHECK (((estatus)::text = ANY (ARRAY[('Activo'::character varying)::text, ('Inactivo'::character varying)::text])))
);


ALTER TABLE public.proveedor OWNER TO postgres;

--
-- Name: proveedor_id_proveedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proveedor_id_proveedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proveedor_id_proveedor_seq OWNER TO postgres;

--
-- Name: proveedor_id_proveedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proveedor_id_proveedor_seq OWNED BY public.proveedor.id_proveedor;


--
-- Name: venta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venta (
    id_venta character varying(15) NOT NULL,
    id_empleado public.curp_dominio,
    total_venta numeric(10,2),
    fecha_venta date,
    id_cliente public.curp_dominio DEFAULT 'XAXX111111HCCXXXX0'::character varying,
    forma_pago character varying(20) DEFAULT 'Efectivo'::character varying
);


ALTER TABLE public.venta OWNER TO postgres;

--
-- Name: venta_detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venta_detalle (
    id_venta character varying(15),
    id_producto public.id_producto_dominio,
    cantidad_producto integer,
    precio_dado numeric(10,2),
    precio_total numeric(10,2),
    tipo_venta public."tipoVenta",
    descuento_pct numeric(5,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.venta_detalle OWNER TO postgres;

--
-- Name: venta_temp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venta_temp (
    id_producto public.id_producto_dominio,
    nombre_p character varying(50),
    cantidad_prod integer,
    precio_dado numeric(10,2),
    precio_total numeric(10,2),
    tipo_venta public."tipoVenta",
    descuento_pct numeric(5,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.venta_temp OWNER TO postgres;

--
-- Name: categoria id_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id_categoria SET DEFAULT nextval('public.categoria_id_categoria_seq'::regclass);


--
-- Name: cotizacion_detalle id_cotizacion_detalle; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion_detalle ALTER COLUMN id_cotizacion_detalle SET DEFAULT nextval('public.cotizacion_detalle_id_cotizacion_detalle_seq'::regclass);


--
-- Name: kardex id_kardex; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kardex ALTER COLUMN id_kardex SET DEFAULT nextval('public.kardex_id_kardex_seq'::regclass);


--
-- Name: lista_precios id_lista; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lista_precios ALTER COLUMN id_lista SET DEFAULT nextval('public.lista_precios_id_lista_seq'::regclass);


--
-- Name: proveedor id_proveedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor ALTER COLUMN id_proveedor SET DEFAULT nextval('public.proveedor_id_proveedor_seq'::regclass);


--
-- Data for Name: apartado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apartado (id_apartado, id_empleado, id_cliente, fecha_inicio, fecha_limite, cantidad_dada, cantidad_faltante, cantidad_total, estado) FROM stdin;
\.
COPY public.apartado (id_apartado, id_empleado, id_cliente, fecha_inicio, fecha_limite, cantidad_dada, cantidad_faltante, cantidad_total, estado) FROM '$$PATH$$/5172.dat';

--
-- Data for Name: apartado_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.apartado_detalle (id_apartado, id_producto, cantidad, precio_unitario, precio_total, tipo) FROM stdin;
\.
COPY public.apartado_detalle (id_apartado, id_producto, cantidad, precio_unitario, precio_total, tipo) FROM '$$PATH$$/5173.dat';

--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id_categoria, nombre, descripcion, estatus) FROM stdin;
\.
COPY public.categoria (id_categoria, nombre, descripcion, estatus) FROM '$$PATH$$/5174.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id_cliente, nombre, telefono, estatus) FROM stdin;
\.
COPY public.cliente (id_cliente, nombre, telefono, estatus) FROM '$$PATH$$/5176.dat';

--
-- Data for Name: compra_producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compra_producto (id_compra, id_producto, cantidad, precio_adquirido, precio_total) FROM stdin;
\.
COPY public.compra_producto (id_compra, id_producto, cantidad, precio_adquirido, precio_total) FROM '$$PATH$$/5177.dat';

--
-- Data for Name: compras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compras (id_compra, id_empleado, fecha_compra, descripcion, monto, id_proveedor) FROM stdin;
\.
COPY public.compras (id_compra, id_empleado, fecha_compra, descripcion, monto, id_proveedor) FROM '$$PATH$$/5178.dat';

--
-- Data for Name: cotizacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cotizacion (id_cotizacion, fecha_cotizacion, id_empleado, id_cliente, total_cotizacion, estatus, id_venta_convertida, fecha_vigencia, notas) FROM stdin;
\.
COPY public.cotizacion (id_cotizacion, fecha_cotizacion, id_empleado, id_cliente, total_cotizacion, estatus, id_venta_convertida, fecha_vigencia, notas) FROM '$$PATH$$/5179.dat';

--
-- Data for Name: cotizacion_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cotizacion_detalle (id_cotizacion_detalle, id_cotizacion, id_producto, nombre_p, cantidad, tipo_venta, precio_dado, descuento_pct, precio_total) FROM stdin;
\.
COPY public.cotizacion_detalle (id_cotizacion_detalle, id_cotizacion, id_producto, nombre_p, cantidad, tipo_venta, precio_dado, descuento_pct, precio_total) FROM '$$PATH$$/5180.dat';

--
-- Data for Name: cotizacion_temp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cotizacion_temp (id_producto, nombre_p, cantidad_prod, tipo_venta, precio_dado, precio_total, descuento_pct) FROM stdin;
\.
COPY public.cotizacion_temp (id_producto, nombre_p, cantidad_prod, tipo_venta, precio_dado, precio_total, descuento_pct) FROM '$$PATH$$/5183.dat';

--
-- Data for Name: devolucion_ventas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devolucion_ventas (id_devolucion, id_venta, fecha_devolucion, monto) FROM stdin;
\.
COPY public.devolucion_ventas (id_devolucion, id_venta, fecha_devolucion, monto) FROM '$$PATH$$/5184.dat';

--
-- Data for Name: devolucion_ventas_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devolucion_ventas_detalle (id_devolucion, id_producto, motivo, cantidad, total) FROM stdin;
\.
COPY public.devolucion_ventas_detalle (id_devolucion, id_producto, motivo, cantidad, total) FROM '$$PATH$$/5185.dat';

--
-- Data for Name: empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empleado (id_empleado, nombre, puesto, telefono, usuario, contrasenia, estatus) FROM stdin;
\.
COPY public.empleado (id_empleado, nombre, puesto, telefono, usuario, contrasenia, estatus) FROM '$$PATH$$/5186.dat';

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresa (id, nombre, razon_social, rfc, telefono, correo, direccion, ciudad, estado, cp, mensaje_ticket, logo_ruta) FROM stdin;
\.
COPY public.empresa (id, nombre, razon_social, rfc, telefono, correo, direccion, ciudad, estado, cp, mensaje_ticket, logo_ruta) FROM '$$PATH$$/5187.dat';

--
-- Data for Name: forma_pago_venta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forma_pago_venta (id_venta, forma_pago, monto) FROM stdin;
\.
COPY public.forma_pago_venta (id_venta, forma_pago, monto) FROM '$$PATH$$/5188.dat';

--
-- Data for Name: gastos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gastos (id_gasto, id_empleado, fecha_gasto, descripcion, monto) FROM stdin;
\.
COPY public.gastos (id_gasto, id_empleado, fecha_gasto, descripcion, monto) FROM '$$PATH$$/5189.dat';

--
-- Data for Name: kardex; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kardex (id_kardex, id_producto, fecha, tipo_movimiento, cantidad, existencia_anterior, existencia_posterior, referencia, id_empleado) FROM stdin;
\.
COPY public.kardex (id_kardex, id_producto, fecha, tipo_movimiento, cantidad, existencia_anterior, existencia_posterior, referencia, id_empleado) FROM '$$PATH$$/5191.dat';

--
-- Data for Name: lista_precios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lista_precios (id_lista, nombre, descripcion, estatus) FROM stdin;
\.
COPY public.lista_precios (id_lista, nombre, descripcion, estatus) FROM '$$PATH$$/5193.dat';

--
-- Data for Name: otras_ganancias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otras_ganancias (id_otras_ganancias, descripcion, monto, fecha_otras_ganancias) FROM stdin;
\.
COPY public.otras_ganancias (id_otras_ganancias, descripcion, monto, fecha_otras_ganancias) FROM '$$PATH$$/5195.dat';

--
-- Data for Name: producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.producto (id_producto, nombre, cantidad, precio_mayoreo, precio_menudeo, id_categoria, max_descuento) FROM stdin;
\.
COPY public.producto (id_producto, nombre, cantidad, precio_mayoreo, precio_menudeo, id_categoria, max_descuento) FROM '$$PATH$$/5196.dat';

--
-- Data for Name: producto_precio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.producto_precio (id_producto, id_lista, precio) FROM stdin;
\.
COPY public.producto_precio (id_producto, id_lista, precio) FROM '$$PATH$$/5197.dat';

--
-- Data for Name: proveedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proveedor (id_proveedor, nombre, telefono, email, direccion, estatus) FROM stdin;
\.
COPY public.proveedor (id_proveedor, nombre, telefono, email, direccion, estatus) FROM '$$PATH$$/5198.dat';

--
-- Data for Name: venta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venta (id_venta, id_empleado, total_venta, fecha_venta, id_cliente, forma_pago) FROM stdin;
\.
COPY public.venta (id_venta, id_empleado, total_venta, fecha_venta, id_cliente, forma_pago) FROM '$$PATH$$/5200.dat';

--
-- Data for Name: venta_detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venta_detalle (id_venta, id_producto, cantidad_producto, precio_dado, precio_total, tipo_venta, descuento_pct) FROM stdin;
\.
COPY public.venta_detalle (id_venta, id_producto, cantidad_producto, precio_dado, precio_total, tipo_venta, descuento_pct) FROM '$$PATH$$/5201.dat';

--
-- Data for Name: venta_temp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venta_temp (id_producto, nombre_p, cantidad_prod, precio_dado, precio_total, tipo_venta, descuento_pct) FROM stdin;
\.
COPY public.venta_temp (id_producto, nombre_p, cantidad_prod, precio_dado, precio_total, tipo_venta, descuento_pct) FROM '$$PATH$$/5202.dat';

--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_id_categoria_seq', 2, true);


--
-- Name: cotizacion_detalle_id_cotizacion_detalle_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cotizacion_detalle_id_cotizacion_detalle_seq', 3, true);


--
-- Name: cotizacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cotizacion_seq', 1, false);


--
-- Name: id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id_producto_seq', 41, true);


--
-- Name: kardex_id_kardex_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kardex_id_kardex_seq', 39, true);


--
-- Name: lista_precios_id_lista_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lista_precios_id_lista_seq', 2, true);


--
-- Name: proveedor_id_proveedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proveedor_id_proveedor_seq', 1, true);


--
-- Name: apartado apartado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apartado
    ADD CONSTRAINT apartado_pkey PRIMARY KEY (id_apartado);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id_categoria);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente);


--
-- Name: compras compras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compras
    ADD CONSTRAINT compras_pkey PRIMARY KEY (id_compra);


--
-- Name: cotizacion_detalle cotizacion_detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion_detalle
    ADD CONSTRAINT cotizacion_detalle_pkey PRIMARY KEY (id_cotizacion_detalle);


--
-- Name: cotizacion cotizacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_pkey PRIMARY KEY (id_cotizacion);


--
-- Name: devolucion_ventas devolucion_ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devolucion_ventas
    ADD CONSTRAINT devolucion_ventas_pkey PRIMARY KEY (id_devolucion);


--
-- Name: empleado empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empleado
    ADD CONSTRAINT empleado_pkey PRIMARY KEY (id_empleado);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (id);


--
-- Name: forma_pago_venta forma_pago_venta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_pago_venta
    ADD CONSTRAINT forma_pago_venta_pkey PRIMARY KEY (id_venta, forma_pago);


--
-- Name: kardex kardex_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kardex
    ADD CONSTRAINT kardex_pkey PRIMARY KEY (id_kardex);


--
-- Name: lista_precios lista_precios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lista_precios
    ADD CONSTRAINT lista_precios_pkey PRIMARY KEY (id_lista);


--
-- Name: otras_ganancias otras_ganancias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otras_ganancias
    ADD CONSTRAINT otras_ganancias_pkey PRIMARY KEY (id_otras_ganancias);


--
-- Name: producto producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_pkey PRIMARY KEY (id_producto);


--
-- Name: producto_precio producto_precio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto_precio
    ADD CONSTRAINT producto_precio_pkey PRIMARY KEY (id_producto, id_lista);


--
-- Name: proveedor proveedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proveedor
    ADD CONSTRAINT proveedor_pkey PRIMARY KEY (id_proveedor);


--
-- Name: venta venta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venta
    ADD CONSTRAINT venta_pkey PRIMARY KEY (id_venta);


--
-- Name: cotizacion trg_gen_id_cotizacion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_gen_id_cotizacion BEFORE INSERT ON public.cotizacion FOR EACH ROW EXECUTE FUNCTION public.gen_id_cotizacion();


--
-- Name: producto trg_kardex_producto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_kardex_producto AFTER UPDATE OF cantidad ON public.producto FOR EACH ROW EXECUTE FUNCTION public.fn_kardex_producto();


--
-- Name: apartado trigger_set_campos_ap; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_ap BEFORE INSERT ON public.apartado FOR EACH ROW EXECUTE FUNCTION public.set_campos_ap();


--
-- Name: apartado_detalle trigger_set_campos_apdet; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_apdet BEFORE INSERT OR UPDATE ON public.apartado_detalle FOR EACH ROW EXECUTE FUNCTION public.set_campos_apdet();


--
-- Name: compras trigger_set_campos_compras; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_compras BEFORE INSERT ON public.compras FOR EACH ROW EXECUTE FUNCTION public.set_campos_compras();


--
-- Name: devolucion_ventas trigger_set_campos_devv; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_devv BEFORE INSERT ON public.devolucion_ventas FOR EACH ROW EXECUTE FUNCTION public.set_campos_devv();


--
-- Name: gastos trigger_set_campos_gstos; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_gstos BEFORE INSERT ON public.gastos FOR EACH ROW EXECUTE FUNCTION public.set_campos_gstos();


--
-- Name: otras_ganancias trigger_set_campos_og; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_og BEFORE INSERT ON public.otras_ganancias FOR EACH ROW EXECUTE FUNCTION public.set_campos_og();


--
-- Name: venta trigger_set_campos_venta; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_set_campos_venta BEFORE INSERT ON public.venta FOR EACH ROW EXECUTE FUNCTION public.set_campos_venta();


--
-- Name: producto trigger_validar_id_producto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_validar_id_producto BEFORE INSERT OR UPDATE ON public.producto FOR EACH ROW EXECUTE FUNCTION public.validar_id_producto();


--
-- Name: venta_temp trigger_verif_exist_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verif_exist_insert BEFORE INSERT ON public.venta_temp FOR EACH ROW EXECUTE FUNCTION public.verif_exist_insert();


--
-- Name: venta_temp trigger_verif_exist_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verif_exist_update BEFORE UPDATE ON public.venta_temp FOR EACH ROW EXECUTE FUNCTION public.verif_exist_update();


--
-- Name: empleado trigger_verif_puesto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verif_puesto BEFORE INSERT OR UPDATE ON public.empleado FOR EACH ROW EXECUTE FUNCTION public.verif_puesto();


--
-- Name: cliente trigger_verif_tel_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verif_tel_c BEFORE INSERT OR UPDATE ON public.cliente FOR EACH ROW EXECUTE FUNCTION public.verif_tel_c();


--
-- Name: empleado trigger_verif_tel_e; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_verif_tel_e BEFORE INSERT OR UPDATE ON public.empleado FOR EACH ROW EXECUTE FUNCTION public.verif_tel_e();


--
-- Name: apartado_detalle apartado_detalle_id_apartado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apartado_detalle
    ADD CONSTRAINT apartado_detalle_id_apartado_fkey FOREIGN KEY (id_apartado) REFERENCES public.apartado(id_apartado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: apartado_detalle apartado_detalle_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apartado_detalle
    ADD CONSTRAINT apartado_detalle_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: apartado apartado_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apartado
    ADD CONSTRAINT apartado_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: apartado apartado_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.apartado
    ADD CONSTRAINT apartado_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: compra_producto compra_producto_id_compra_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compra_producto
    ADD CONSTRAINT compra_producto_id_compra_fkey FOREIGN KEY (id_compra) REFERENCES public.compras(id_compra) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: compra_producto compra_producto_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compra_producto
    ADD CONSTRAINT compra_producto_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: compras compras_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compras
    ADD CONSTRAINT compras_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: compras compras_id_proveedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compras
    ADD CONSTRAINT compras_id_proveedor_fkey FOREIGN KEY (id_proveedor) REFERENCES public.proveedor(id_proveedor);


--
-- Name: cotizacion_detalle cotizacion_detalle_id_cotizacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion_detalle
    ADD CONSTRAINT cotizacion_detalle_id_cotizacion_fkey FOREIGN KEY (id_cotizacion) REFERENCES public.cotizacion(id_cotizacion) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cotizacion_detalle cotizacion_detalle_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion_detalle
    ADD CONSTRAINT cotizacion_detalle_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cotizacion cotizacion_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cotizacion cotizacion_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cotizacion cotizacion_id_venta_convertida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion
    ADD CONSTRAINT cotizacion_id_venta_convertida_fkey FOREIGN KEY (id_venta_convertida) REFERENCES public.venta(id_venta) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cotizacion_temp cotizacion_temp_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cotizacion_temp
    ADD CONSTRAINT cotizacion_temp_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devolucion_ventas_detalle devolucion_ventas_detalle_id_devolucion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devolucion_ventas_detalle
    ADD CONSTRAINT devolucion_ventas_detalle_id_devolucion_fkey FOREIGN KEY (id_devolucion) REFERENCES public.devolucion_ventas(id_devolucion) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devolucion_ventas_detalle devolucion_ventas_detalle_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devolucion_ventas_detalle
    ADD CONSTRAINT devolucion_ventas_detalle_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devolucion_ventas devolucion_ventas_id_venta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devolucion_ventas
    ADD CONSTRAINT devolucion_ventas_id_venta_fkey FOREIGN KEY (id_venta) REFERENCES public.venta(id_venta) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: forma_pago_venta forma_pago_venta_id_venta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forma_pago_venta
    ADD CONSTRAINT forma_pago_venta_id_venta_fkey FOREIGN KEY (id_venta) REFERENCES public.venta(id_venta);


--
-- Name: gastos gastos_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gastos
    ADD CONSTRAINT gastos_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kardex kardex_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kardex
    ADD CONSTRAINT kardex_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado);


--
-- Name: kardex kardex_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kardex
    ADD CONSTRAINT kardex_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto);


--
-- Name: producto producto_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


--
-- Name: producto_precio producto_precio_id_lista_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto_precio
    ADD CONSTRAINT producto_precio_id_lista_fkey FOREIGN KEY (id_lista) REFERENCES public.lista_precios(id_lista) ON DELETE CASCADE;


--
-- Name: producto_precio producto_precio_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto_precio
    ADD CONSTRAINT producto_precio_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON DELETE CASCADE;


--
-- Name: venta_detalle venta_detalle_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venta_detalle
    ADD CONSTRAINT venta_detalle_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: venta_detalle venta_detalle_id_venta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venta_detalle
    ADD CONSTRAINT venta_detalle_id_venta_fkey FOREIGN KEY (id_venta) REFERENCES public.venta(id_venta) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: venta venta_id_empleado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venta
    ADD CONSTRAINT venta_id_empleado_fkey FOREIGN KEY (id_empleado) REFERENCES public.empleado(id_empleado) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: venta_temp venta_temp_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venta_temp
    ADD CONSTRAINT venta_temp_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

